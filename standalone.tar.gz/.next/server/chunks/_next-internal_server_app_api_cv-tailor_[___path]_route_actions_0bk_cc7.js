module.exports=[547316,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cv-tailor_%5B___path%5D_route_actions_0bk_cc7.js.map