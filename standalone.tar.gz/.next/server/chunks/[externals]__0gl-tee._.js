module.exports=[224361,(e,r,t)=>{r.exports=e.x("util",()=>require("util"))},522734,(e,r,t)=>{r.exports=e.x("fs",()=>require("fs"))},688947,(e,r,t)=>{r.exports=e.x("stream",()=>require("stream"))},921517,(e,r,t)=>{r.exports=e.x("http",()=>require("http"))},500874,(e,r,t)=>{r.exports=e.x("buffer",()=>require("buffer"))}];

//# sourceMappingURL=%5Bexternals%5D__0gl-tee._.js.map