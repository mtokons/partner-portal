module.exports=[488098,(e,o,r)=>{o.exports=e.x("teleproto-2fb32e11b7f255c2/Password.js",()=>require("teleproto-2fb32e11b7f255c2/Password.js"))}];

//# sourceMappingURL=%5Bexternals%5D_teleproto_Password_10de48r.js.map