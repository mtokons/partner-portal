module.exports=[490497,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_notifications_mark-all_route_actions_0watpk9.js.map