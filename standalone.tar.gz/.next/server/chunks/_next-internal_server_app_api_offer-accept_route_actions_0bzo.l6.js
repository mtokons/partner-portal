module.exports=[298513,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_offer-accept_route_actions_0bzo.l6.js.map