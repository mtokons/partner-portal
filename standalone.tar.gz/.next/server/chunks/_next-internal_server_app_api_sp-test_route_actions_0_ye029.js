module.exports=[764453,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sp-test_route_actions_0_ye029.js.map