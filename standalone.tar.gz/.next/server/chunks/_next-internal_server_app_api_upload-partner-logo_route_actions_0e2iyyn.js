module.exports=[448996,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_upload-partner-logo_route_actions_0e2iyyn.js.map