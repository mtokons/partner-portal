module.exports=[982775,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_invoice-pdf_route_actions_0fgyf6d.js.map