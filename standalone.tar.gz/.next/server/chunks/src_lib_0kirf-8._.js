module.exports=[320080,e=>{"use strict";e.s(["dual",0,function(e,t,r,o){return`€${e.toLocaleString("en",{minimumFractionDigits:0})}`},"dualHtml",0,function(e,t,r){return`<strong>€${e.toLocaleString("en",{minimumFractionDigits:2})}</strong>`},"formatBdtEur",0,function(e,t,r=2){return"number"==typeof t?`€${t.toFixed(r)}`:`€${e.toFixed(r)}`},"formatEurWithRate",0,function(e,t,r=2){return`€${e.toFixed(r)}`}])},492749,e=>{"use strict";var t=e.i(232657);let r=process.env.O365_SENDER_USER_ID||"portal@mysccg.de";async function o(e){let o=e.senderUserId||r,d=[{emailAddress:{address:e.to,name:e.toName||e.to}}],a=(e.cc||[]).map(e=>({emailAddress:{address:e.email,name:e.name||e.email}})),i=(e.attachments||[]).map(e=>({"@odata.type":"#microsoft.graph.fileAttachment",name:e.name,contentType:e.contentType,contentBytes:e.contentBase64})),n={message:{subject:e.subject,body:{contentType:"HTML",content:e.htmlBody},toRecipients:d,...a.length>0&&{ccRecipients:a},...i.length>0&&{attachments:i}},saveToSentItems:!1!==e.saveToSentItems};await (0,t.graphPost)(`/users/${o}/sendMail`,n)}e.s(["buildCandidateLoginEmail",0,function(e){let t=e.tempPassword?`
      <div style="background: #fffbeb; border: 1px solid #f59e0b; border-radius: 8px; padding: 20px; margin: 20px 0;">
        <h3 style="margin: 0 0 12px; font-size: 14px; color: #b45309;">🔐 Your Login Credentials</h3>
        <table style="width: 100%; border-collapse: collapse;">
          <tr><td style="padding: 6px 0; color: #64748b; width: 140px;">Email</td><td style="padding: 6px 0; font-weight: bold;">${e.email}</td></tr>
          <tr><td style="padding: 6px 0; color: #64748b;">Temporary Password</td><td style="padding: 6px 0; font-family: monospace; background: #f1f5f9; padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 15px; letter-spacing: 1px;">${e.tempPassword}</td></tr>
        </table>
        <p style="color: #dc2626; font-size: 13px; margin: 12px 0 0;">⚠️ Please change your password after your first login for security.</p>
      </div>`:`
      <div style="background: #f0fdf4; border: 1px solid #22c55e; border-radius: 8px; padding: 16px; margin: 20px 0;">
        <h3 style="margin: 0 0 12px; font-size: 14px; color: #166534;">🔐 Your Login Details</h3>
        <table style="width: 100%; border-collapse: collapse;">
          <tr><td style="padding: 6px 0; color: #64748b; width: 140px;">Username (Email)</td><td style="padding: 6px 0; font-weight: bold;">${e.email}</td></tr>
        </table>
        <p style="margin: 12px 0 0; color: #166534; font-size: 13px;">✓ You already have an account. Please log in with your existing password. If you have forgotten it, use the “Forgot password” link on the login page.</p>
      </div>`,r=e.totalServiceFee?`<tr><td style="padding: 8px 0; color: #64748b;">Total Service Fee</td><td style="padding: 8px 0; font-weight: bold;">€${e.totalServiceFee.toFixed(2)}</td></tr>`:"";return{subject:"Welcome to SCCG Career Lab Germany — Your Portal Login Details",htmlBody:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #0a1628, #1a2a4a); padding: 32px; border-radius: 12px 12px 0 0;">
          <h1 style="color: #ffffff; margin: 0; font-size: 24px;">Welcome to SCCG Career Lab Germany</h1>
          <p style="color: #94a3b8; margin: 8px 0 0;">Your Portal Account is Ready</p>
        </div>
        <div style="background: #ffffff; padding: 32px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
          <p>Dear <strong>${e.candidateName}</strong>,</p>
          <p>You have been registered by <strong>${e.partnerName}</strong> for the <strong>${e.workflowCategory}</strong> program.</p>
          
          <table style="width: 100%; margin: 16px 0; border-collapse: collapse;">
            <tr><td style="padding: 8px 0; color: #64748b;">Registration ID</td><td style="padding: 8px 0; font-weight: bold;">${e.sccgId}</td></tr>
            <tr><td style="padding: 8px 0; color: #64748b;">Program</td><td style="padding: 8px 0;">${e.workflowCategory}</td></tr>
            ${r}
          </table>

          ${t}

          <div style="text-align: center; margin: 24px 0;">
            <a href="${e.loginUrl}" style="display: inline-block; background: linear-gradient(135deg, #2563eb, #1d4ed8); color: #ffffff; padding: 14px 32px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 16px;">Log In to Your Portal</a>
          </div>

          <p>After logging in, you can:</p>
          <ul style="color: #334155; line-height: 1.8;">
            <li>✓ View your service offers and details</li>
            <li>✓ Track your application timeline</li>
            <li>✓ View payment history</li>
            <li>✓ Send messages to your partner</li>
            <li>✓ Upload required documents</li>
          </ul>
          
          <p style="color: #64748b; font-size: 13px; margin-top: 24px;">
            Best regards,<br/>
            <strong>SCCG Career Lab Germany</strong><br/>
            Website: <a href="https://www.mysccg.de/" style="color: #2563eb;">www.mysccg.de</a>
          </p>
        </div>
      </div>
    `}},"buildServiceAddedEmail",0,function(e){let t=e.services.map(e=>`<tr><td style="padding: 8px 0; color: #334155;">${e.serviceName}${e.quantity>1?` \xd7 ${e.quantity}`:""}</td><td style="padding: 8px 0; text-align: right; font-weight: bold;">€${e.totalPrice.toFixed(2)}</td></tr>`).join("");return{subject:`New Service Added to Your SCCG Registration — ${e.sccgId}`,htmlBody:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #0a1628, #1a2a4a); padding: 32px; border-radius: 12px 12px 0 0;">
          <h1 style="color: #ffffff; margin: 0; font-size: 24px;">New Service Added</h1>
          <p style="color: #94a3b8; margin: 8px 0 0;">SCCG Career Lab Germany</p>
        </div>
        <div style="background: #ffffff; padding: 32px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
          <p>Dear <strong>${e.candidateName}</strong>,</p>
          <p><strong>${e.partnerName}</strong> has added the following service(s) to your registration (<strong>${e.sccgId}</strong>):</p>
          <table style="width: 100%; margin: 16px 0; border-collapse: collapse;">
            ${t}
            <tr><td style="padding: 10px 0 0; border-top: 1px solid #e2e8f0; color: #64748b;">Added Amount</td><td style="padding: 10px 0 0; border-top: 1px solid #e2e8f0; text-align: right; font-weight: bold;">€${e.addedAmount.toFixed(2)}</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">New Total Service Fee</td><td style="padding: 6px 0; text-align: right; font-weight: bold;">€${e.newTotal.toFixed(2)}</td></tr>
          </table>
          <div style="text-align: center; margin: 24px 0;">
            <a href="${e.loginUrl}" style="display: inline-block; background: linear-gradient(135deg, #2563eb, #1d4ed8); color: #ffffff; padding: 14px 32px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 16px;">View in Your Portal</a>
          </div>
          <p>Log in to your portal to review the updated details, payment information, and your application timeline.</p>
          <p style="color: #64748b; font-size: 13px; margin-top: 24px;">
            Best regards,<br/>
            <strong>SCCG Career Lab Germany</strong><br/>
            Website: <a href="https://www.mysccg.de/" style="color: #2563eb;">www.mysccg.de</a>
          </p>
        </div>
      </div>
    `}},"sendEmailViaGraph",0,o])}];

//# sourceMappingURL=src_lib_0kirf-8._.js.map