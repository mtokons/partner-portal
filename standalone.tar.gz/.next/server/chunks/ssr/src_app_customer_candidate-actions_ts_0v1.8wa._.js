module.exports=[705223,a=>{"use strict";var b=a.i(137936),c=a.i(590048),d=a.i(277108),e=a.i(208134),f=a.i(118558);async function g(b){try{let{getAdminFirestore:c}=await a.A(961007),d=c(),e=await d.collection("partnerPaymentInfo").doc(b).get();if(!e.exists)return null;return e.data()}catch{return null}}async function h(b){try{var c,e;let h=await j();if(!h.email)return{success:!1,error:"No email on session"};let i=await (0,d.getSalesOfferById)(b);if(!i)return{success:!1,error:"Offer not found"};let k=h.email.toLowerCase().trim();if(i.clientEmail?.toLowerCase().trim()!==k&&i.prospectEmail?.toLowerCase().trim()!==k)return{success:!1,error:"Access denied"};if("accepted"===i.status)return{success:!1,error:"You have already accepted this offer."};if("sent"!==i.status)return{success:!1,error:"This offer is no longer available for acceptance."};let l=(await (0,d.getCandidates)(i.partnerId)).some(a=>a.email.toLowerCase().trim()===k);await (0,d.updateSalesOffer)(b,{status:"accepted",acceptedAt:new Date().toISOString()});let[m,n]=await Promise.all([g(i.partnerId),(0,d.getPartners)()]),o=n.find(a=>a.id===i.partnerId),p=h.name||i.clientName||"Candidate",q=i.partnerName||o?.name||"SCCG Partner",r=i.totalAmount;try{let b,{sendEmailViaGraph:d}=await a.A(474019);await d({to:h.email,toName:p,subject:`Offer Accepted — ${i.offerNumber} \xb7 SCCG`,htmlBody:(b=(c={candidateName:p,offerNumber:i.offerNumber,partnerName:q,totalAmount:r,paymentInfo:m,partnerEmail:o?.email,partnerPhone:o?.phone}).paymentInfo&&Object.values(c.paymentInfo).some(Boolean)?`
      <div style="background: #f0fdf4; border: 1px solid #86efac; border-radius: 8px; padding: 20px; margin: 24px 0;">
        <h3 style="margin: 0 0 12px; font-size: 15px; color: #15803d;">Payment Details</h3>
        <p style="margin: 0 0 8px; font-size: 13px; color: #166534;">Please transfer <strong>€${c.totalAmount.toFixed(2)}</strong> to your partner using the details below:</p>
        <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
          ${c.paymentInfo.accountHolderName?`<tr><td style="padding: 5px 0; color: #6b7280; width: 160px;">Account Holder</td><td style="padding: 5px 0; font-weight: bold;">${c.paymentInfo.accountHolderName}</td></tr>`:""}
          ${c.paymentInfo.bankName?`<tr><td style="padding: 5px 0; color: #6b7280;">Bank Name</td><td style="padding: 5px 0;">${c.paymentInfo.bankName}</td></tr>`:""}
          ${c.paymentInfo.iban?`<tr><td style="padding: 5px 0; color: #6b7280;">IBAN</td><td style="padding: 5px 0; font-family: monospace; font-weight: bold;">${c.paymentInfo.iban}</td></tr>`:""}
          ${c.paymentInfo.bic?`<tr><td style="padding: 5px 0; color: #6b7280;">BIC / SWIFT</td><td style="padding: 5px 0; font-family: monospace;">${c.paymentInfo.bic}</td></tr>`:""}
          ${c.paymentInfo.accountNumber?`<tr><td style="padding: 5px 0; color: #6b7280;">Account Number</td><td style="padding: 5px 0; font-family: monospace;">${c.paymentInfo.accountNumber}</td></tr>`:""}
          ${c.paymentInfo.paymentNote?`<tr><td style="padding: 5px 0; color: #6b7280; vertical-align: top;">Instructions</td><td style="padding: 5px 0;">${c.paymentInfo.paymentNote}</td></tr>`:""}
        </table>
      </div>
    `:`
      <div style="background: #fff7ed; border: 1px solid #fdba74; border-radius: 8px; padding: 16px; margin: 24px 0;">
        <p style="margin: 0; font-size: 13px; color: #92400e;">Your partner has not yet set up their payment details in the portal. Please contact <strong>${c.partnerName}</strong> directly${c.partnerEmail?` at <a href="mailto:${c.partnerEmail}" style="color: #d97706;">${c.partnerEmail}</a>`:""}${c.partnerPhone?` or ${c.partnerPhone}`:""} to arrange payment.</p>
      </div>
    `,`
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background: linear-gradient(135deg, #0a1628, #1a2a4a); padding: 32px; border-radius: 12px 12px 0 0;">
        <h1 style="color: #ffffff; margin: 0; font-size: 24px;">Offer Accepted</h1>
        <p style="color: #94a3b8; margin: 8px 0 0;">Offer #${c.offerNumber}</p>
      </div>
      <div style="background: #ffffff; padding: 32px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
        <p>Dear <strong>${c.candidateName}</strong>,</p>
        <p>Congratulations! You have successfully accepted the offer <strong>${c.offerNumber}</strong> from <strong>${c.partnerName}</strong>.</p>
        <table style="width: 100%; border-collapse: collapse; background: #f8fafc; border-radius: 8px; overflow: hidden; margin: 20px 0;">
          <tr><td style="padding: 12px 16px; color: #64748b; width: 140px;">Offer Number</td><td style="padding: 12px 16px; font-weight: bold;">${c.offerNumber}</td></tr>
          <tr style="background: #f1f5f9;"><td style="padding: 12px 16px; color: #64748b;">Partner</td><td style="padding: 12px 16px;">${c.partnerName}</td></tr>
          <tr><td style="padding: 12px 16px; color: #64748b;">Total Amount</td><td style="padding: 12px 16px; font-weight: bold; color: #0284c7;">€${c.totalAmount.toFixed(2)}</td></tr>
        </table>
        ${b}
        <p>Your partner will complete your registration and you will receive further instructions shortly.</p>
        <p>You can track your service progress in the SCCG Partner Portal at any time.</p>
        <p style="color: #64748b; font-size: 13px; margin-top: 24px;">Best regards,<br/><strong>SCCG Career Lab Germany</strong><br/><a href="https://www.mysccg.de/" style="color: #2563eb;">www.mysccg.de</a></p>
      </div>
    </div>
  `)})}catch{}try{if(o?.email){let{sendEmailViaGraph:b}=await a.A(474019);await b({to:o.email,toName:q,subject:`Offer Accepted by ${p} — ${i.offerNumber}`,htmlBody:(e={partnerName:q,candidateName:p,candidateEmail:h.email,offerNumber:i.offerNumber,totalAmount:r,acceptedAt:new Date().toLocaleDateString("en-GB")},`
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background: linear-gradient(135deg, #0f4c35, #16a34a); padding: 32px; border-radius: 12px 12px 0 0;">
        <h1 style="color: #ffffff; margin: 0; font-size: 24px;">Offer Accepted!</h1>
        <p style="color: #bbf7d0; margin: 8px 0 0;">A candidate has accepted your offer</p>
      </div>
      <div style="background: #ffffff; padding: 32px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
        <p>Dear <strong>${e.partnerName}</strong>,</p>
        <p>Great news! <strong>${e.candidateName}</strong> has accepted your offer and is ready to proceed.</p>
        <table style="width: 100%; border-collapse: collapse; background: #f8fafc; border-radius: 8px; overflow: hidden; margin: 20px 0;">
          <tr><td style="padding: 12px 16px; color: #64748b; width: 150px;">Candidate</td><td style="padding: 12px 16px; font-weight: bold;">${e.candidateName}</td></tr>
          <tr style="background: #f1f5f9;"><td style="padding: 12px 16px; color: #64748b;">Email</td><td style="padding: 12px 16px;"><a href="mailto:${e.candidateEmail}" style="color: #2563eb;">${e.candidateEmail}</a></td></tr>
          <tr><td style="padding: 12px 16px; color: #64748b;">Offer Number</td><td style="padding: 12px 16px; font-family: monospace;">${e.offerNumber}</td></tr>
          <tr style="background: #f1f5f9;"><td style="padding: 12px 16px; color: #64748b;">Total Amount</td><td style="padding: 12px 16px; font-weight: bold; color: #0284c7;">€${e.totalAmount.toFixed(2)}</td></tr>
          <tr><td style="padding: 12px 16px; color: #64748b;">Accepted On</td><td style="padding: 12px 16px;">${e.acceptedAt}</td></tr>
        </table>
        <p><strong>Next steps:</strong> Please log into the SCCG Partner Portal to complete the candidate's registration and set up their service timeline.</p>
        <p style="color: #64748b; font-size: 13px; margin-top: 24px;">— SCCG Career Lab Germany<br/><a href="https://portal.mysccg.de" style="color: #2563eb;">portal.mysccg.de</a></p>
      </div>
    </div>
  `)})}}catch{}return(0,f.revalidatePath)(`/customer/offers/${b}`),(0,f.revalidatePath)("/customer/offers"),{success:!0,paymentInfo:m,alreadyRegistered:l}}catch(a){return{success:!1,error:a instanceof Error?a.message:"Something went wrong"}}}async function i(b,c){try{let e=await j();if(!e.email)return{success:!1,error:"No email on session"};let f=await (0,d.getSalesOfferById)(b);if(!f)return{success:!1,error:"Offer not found"};let g=e.email.toLowerCase().trim();if(f.clientEmail?.toLowerCase().trim()!==g&&f.prospectEmail?.toLowerCase().trim()!==g)return{success:!1,error:"Access denied"};let h=(await (0,d.getPartners)()).find(a=>a.id===f.partnerId);if(!h?.email)return{success:!1,error:"Partner contact not found"};let i=e.name||f.clientName||e.email,k=f.partnerName||h.name||"Partner",{sendEmailViaGraph:l}=await a.A(474019);return await l({to:h.email,toName:k,subject:`New Offer Request from ${i} — Re: ${f.offerNumber}`,htmlBody:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #0a1628, #1a2a4a); padding: 32px; border-radius: 12px 12px 0 0;">
            <h1 style="color: #ffffff; margin: 0; font-size: 22px;">New Offer Request</h1>
            <p style="color: #94a3b8; margin: 6px 0 0;">Re: Offer ${f.offerNumber}</p>
          </div>
          <div style="background: #ffffff; padding: 32px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
            <p>Dear <strong>${k}</strong>,</p>
            <p>Your candidate <strong>${i}</strong> (${e.email}) has requested a new or revised offer for <strong>${f.offerNumber}</strong>.</p>
            <div style="background: #f8fafc; border-left: 4px solid #6366f1; border-radius: 4px; padding: 16px; margin: 20px 0;">
              <p style="margin: 0; font-size: 14px; color: #334155;"><strong>Message from candidate:</strong></p>
              <p style="margin: 8px 0 0; color: #475569;">${c.replace(/</g,"&lt;").replace(/>/g,"&gt;")}</p>
            </div>
            <p style="color: #64748b; font-size: 13px; margin-top: 24px;">Please log into the SCCG Partner Portal to create a revised offer.<br/>— SCCG Career Lab Germany</p>
          </div>
        </div>
      `}),{success:!0}}catch(a){return{success:!1,error:a instanceof Error?a.message:"Failed to send request"}}}async function j(){let a=await (0,c.getEffectiveUser)();if(!a)throw Error("Unauthorized");if(!(a.roles||[a.role]).includes("customer"))throw Error("Not a customer");return a}async function k(){let a=await j();return a.email?(await (0,d.getCandidates)()).filter(b=>b.email.toLowerCase().trim()===a.email.toLowerCase().trim()):[]}async function l(a){let b=await j(),c=await (0,d.getCandidateById)(a);return c&&c.email.toLowerCase().trim()===b.email.toLowerCase().trim()?(0,d.getCandidateServices)(a):[]}async function m(){let a=await j();if(!a.email)return[];let b=a.email.toLowerCase().trim(),c=await (0,d.getCustomerByEmail)(a.email);if(c){let a=(await (0,d.getSalesOffers)(c.partnerId)).filter(a=>a.clientEmail?.toLowerCase().trim()===b||a.prospectEmail?.toLowerCase().trim()===b);if(a.length>0)return a}return(await (0,d.getSalesOffers)()).filter(a=>a.clientEmail?.toLowerCase().trim()===b||a.prospectEmail?.toLowerCase().trim()===b)}async function n(a){let b=await j(),c=await (0,d.getSalesOfferById)(a);return c&&(c.clientEmail?.toLowerCase().trim()===b.email.toLowerCase().trim()||c.prospectEmail?.toLowerCase().trim()===b.email.toLowerCase().trim())?{offer:c,items:await (0,d.getSalesOfferItems)(a)}:null}async function o(){if(!(await j()).email)return{context:"empty",candidates:[],offers:[],hasServices:!1};let[a,b]=await Promise.all([k(),m()]),c=!1;for(let b of a)if((await (0,d.getCandidateServices)(b.id)).length>0){c=!0;break}return c||a.length>0?{context:"active",candidates:a,offers:b,hasServices:c}:b.length>0?{context:"offer-only",candidates:a,offers:b,hasServices:!1}:{context:"empty",candidates:a,offers:b,hasServices:!1}}async function p(){let a=await j();return a.email?(await (0,d.getHelpdeskTickets)()).filter(b=>b.submittedByEmail.toLowerCase().trim()===a.email.toLowerCase().trim()):[]}async function q(a){let b=await j(),c=(await (0,d.getHelpdeskTickets)()).find(b=>b.id===a);return c&&c.submittedByEmail.toLowerCase().trim()===b.email.toLowerCase().trim()?{ticket:c,messages:await (0,d.getHelpdeskMessages)(a)}:{ticket:null,messages:[]}}async function r(b){try{let c=await j();if(!c.email)return{success:!1,error:"No email"};let g=await k(),h=g[0]?.partnerId||"",i=await (0,e.generateSccgId)("HLP"),l=await (0,d.createHelpdeskTicket)({sccgId:i,submittedByUserId:c.id,submittedByName:c.name||c.email,submittedByEmail:c.email,partnerId:h,category:"candidate",priority:"regular",subject:b.subject,description:b.message,status:"open",relatedCandidateId:b.candidateId,createdAt:new Date().toISOString()});try{if(h){let{getPartners:d}=await a.A(627817),e=(await d()).find(a=>a.id===h);if(e?.email){let{sendEmailViaGraph:d}=await a.A(474019);await d({to:e.email,toName:e.name,subject:`New Message from ${c.name||c.email} — ${b.subject}`,htmlBody:`
              <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <div style="background: linear-gradient(135deg, #0a1628, #1a2a4a); padding: 24px; border-radius: 12px 12px 0 0;">
                  <h2 style="color: #ffffff; margin: 0;">New Candidate Message</h2>
                </div>
                <div style="background: #ffffff; padding: 24px; border: 1px solid #e2e8f0; border-radius: 0 0 12px 12px;">
                  <p><strong>From:</strong> ${c.name||c.email}</p>
                  <p><strong>Subject:</strong> ${b.subject}</p>
                  <div style="background: #f8fafc; padding: 16px; border-radius: 8px; margin: 16px 0;">
                    <p style="margin: 0; white-space: pre-wrap;">${b.message}</p>
                  </div>
                  <p style="color: #64748b; font-size: 13px;">Please log in to the portal to reply.</p>
                </div>
              </div>
            `})}}}catch{}return(0,f.revalidatePath)("/customer/messages"),{success:!0,ticketId:l.id}}catch(a){return{success:!1,error:a instanceof Error?a.message:"Failed to send"}}}async function s(a,b){try{let c=await j(),e=(await (0,d.getHelpdeskTickets)()).find(b=>b.id===a);if(!e||e.submittedByEmail.toLowerCase()!==c.email.toLowerCase())return{success:!1,error:"Ticket not found"};return await (0,d.createHelpdeskMessage)({ticketId:a,senderUserId:c.id,senderName:c.name||c.email,isStaff:!1,message:b,createdAt:new Date().toISOString()}),(0,f.revalidatePath)(`/customer/messages/${a}`),{success:!0}}catch(a){return{success:!1,error:a instanceof Error?a.message:"Failed to reply"}}}(0,a.i(713095).ensureServerEntryExports)([g,h,i,k,l,m,n,o,p,q,r,s]),(0,b.registerServerReference)(g,"40ef4de7c5f83214be618b99f3e73ca32694a29348",null),(0,b.registerServerReference)(h,"4081ed39d2c2f46caccac1e2d27c7bdde3b800f5a7",null),(0,b.registerServerReference)(i,"60f42b9e83b31933a37ad5d4fa9b94381110df6b2f",null),(0,b.registerServerReference)(k,"00595c89cfbfd2b4cbeb1bd45f07371699210e3a28",null),(0,b.registerServerReference)(l,"40cd4f66f024605d8e3d091842820b8384a6f0c9c3",null),(0,b.registerServerReference)(m,"00ed21f52032932eaa69846b21a0e5fffa7f2b6551",null),(0,b.registerServerReference)(n,"40cdb21bec024d3bed96fa632de9ca9e86907da435",null),(0,b.registerServerReference)(o,"001f85de3e50053f66fef6d22ff281b4eef1da3090",null),(0,b.registerServerReference)(p,"00e965dead06de6d19db22d977de32f45229809836",null),(0,b.registerServerReference)(q,"40374ff541a4bcb51bf2d3152e26200189e103dff2",null),(0,b.registerServerReference)(r,"40470c6ea8a0c1bf20e28324bce421ece4b3498a7e",null),(0,b.registerServerReference)(s,"60fc7082b009c7b202e278107f1d30fe89f64771d8",null),a.s(["acceptOfferAction",0,h,"getCandidatePortalContext",0,o,"getMyCandidateRecords",0,k,"getMyCandidateServices",0,l,"getMyConversation",0,q,"getMyMessages",0,p,"getMyOfferDetail",0,n,"getMyOffers",0,m,"getPartnerPaymentInfo",0,g,"replyToConversation",0,s,"requestNewOfferAction",0,i,"sendMessageToPartner",0,r])}];

//# sourceMappingURL=src_app_customer_candidate-actions_ts_0v1.8wa._.js.map