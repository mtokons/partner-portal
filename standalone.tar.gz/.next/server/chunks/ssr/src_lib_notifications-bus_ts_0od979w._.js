module.exports=[17887,a=>{"use strict";let b=globalThis;b.__notifBus||(b.__notifBus={listeners:new Map});let c=b.__notifBus;a.s(["publish",0,function(a){let b=c.listeners.get(a.userId);if(b)for(let c of b)try{c(a)}catch{}}])}];

//# sourceMappingURL=src_lib_notifications-bus_ts_0od979w._.js.map