module.exports=[56491,t=>{"use strict";let e=globalThis;e.__notifBus||(e.__notifBus={listeners:new Map});let s=e.__notifBus;t.s(["publish",0,function(t){let e=s.listeners.get(t.userId);if(e)for(let s of e)try{s(t)}catch{}}])}];

//# sourceMappingURL=src_lib_notifications-bus_ts_0u1sykj._.js.map