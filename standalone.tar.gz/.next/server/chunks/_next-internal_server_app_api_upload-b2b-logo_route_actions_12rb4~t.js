module.exports=[645784,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_upload-b2b-logo_route_actions_12rb4~t.js.map