var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[root-of-the-server]__0fnxs6p._.js")
R.c("server/chunks/node_modules_next_0qds1ne._.js")
R.c("server/chunks/[root-of-the-server]__02b6vtz._.js")
R.c("server/chunks/src_lib_sharepoint_ts_1289q4h._.js")
R.m(489997)
module.exports=R.m(489997).exports
