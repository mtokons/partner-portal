globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/jPda1FAgEFkUgAJ6jbUW8/_buildManifest.js",
    "static/jPda1FAgEFkUgAJ6jbUW8/_ssgManifest.js",
    "static/jPda1FAgEFkUgAJ6jbUW8/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0-hrh_uw98wb_.js",
    "static/chunks/0~k6u5_j-9bf2.js",
    "static/chunks/0o2vrd9qzqk-p.js",
    "static/chunks/17-7.4~j4.9i9.js",
    "static/chunks/18cilrg3kkkfk.js",
    "static/chunks/128aahewwf1we.js",
    "static/chunks/turbopack-0._bmwcxpk.tt.js"
  ]
};
