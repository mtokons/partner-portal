"use strict";exports.id=3838,exports.ids=[3838,6994],exports.modules={33838:(a,b,c)=>{c.d(b,{buildB2BCertificateEmail:()=>i,buildCandidateLoginEmail:()=>h,buildPartnerOfferEmail:()=>k,buildPaymentConfirmationEmail:()=>g,buildServiceAddedEmail:()=>j,sendEmailViaGraph:()=>f});var d=c(56994);let e=process.env.O365_SENDER_USER_ID||"portal@mysccg.de";async function f(a){let b=a.senderUserId||e,c=[{emailAddress:{address:a.to,name:a.toName||a.to}}],f=(a.cc||[]).map(a=>({emailAddress:{address:a.email,name:a.name||a.email}})),g=(a.bcc||[]).map(a=>({emailAddress:{address:a.email,name:a.name||a.email}})),h=(a.attachments||[]).map(a=>({"@odata.type":"#microsoft.graph.fileAttachment",name:a.name,contentType:a.contentType,contentBytes:a.contentBase64})),i={message:{subject:a.subject,body:{contentType:"HTML",content:a.htmlBody},toRecipients:c,...f.length>0&&{ccRecipients:f},...g.length>0&&{bccRecipients:g},...h.length>0&&{attachments:h}},saveToSentItems:!1!==a.saveToSentItems};await (0,d.graphPost)(`/users/${b}/sendMail`,i)}function g(a){let{dualHtml:b}=c(49110),d=a.secondaryCurrency&&a.exchangeRate?b(a.amount,a.secondaryCurrency,a.exchangeRate):`€${a.amount.toFixed(2)}`;return{subject:`Payment Confirmation — SCCG Career Lab Germany (${a.plan})`,htmlBody:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #0a1628, #1a2a4a); padding: 32px; border-radius: 12px 12px 0 0; color: #ffffff;">
          <h1 style="margin: 0; font-size: 24px;">Payment Confirmation</h1>
          <p style="margin: 8px 0 0; opacity: 0.9;">SCCG Partner Portal</p>
        </div>
        <div style="background: #ffffff; padding: 32px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
          <p>Dear <strong>\${data.clientName}</strong>,</p>
          <p>Thank you for choosing SCCG: Study and Career Coach Germany! We are pleased to confirm that we have received your payment for the (\${data.plan}) on \${data.paymentDate}.</p>
          <h3 style="margin-top: 24px; color: #334155;">Payment Details:</h3>
          <table style="width: 100%; margin: 12px 0 24px; border-collapse: collapse;">
            <tr><td style="padding: 8px 0; color: #64748b;">Paid Amount:</td><td style="padding: 8px 0; font-weight: bold;">${d}</td></tr>
            <tr><td style="padding: 8px 0; color: #64748b;">Payment Method:</td><td style="padding: 8px 0;">\${data.method}</td></tr>
            <tr><td style="padding: 8px 0; color: #64748b;">SCCG Plan:</td><td style="padding: 8px 0;">\${data.plan}</td></tr>
          </table>
          <p>We are currently organizing a professional session with one of our experts tailored to your needs. You will receive a meeting invitation within the next 10 days.</p>
          <p>In the meantime, if you have any questions, please feel free to reach out by email or WhatsApp at +4915905840718.</p>
          <p>Thank you again for your payment and trust in SCCG. We look forward to supporting your career journey!</p>
          <p style="color: #64748b; font-size: 13px; margin-top: 24px;">
            Best Regards,<br/>
            <strong>\${data.partnerName}</strong><br/>
            Study and Career Coach Germany<br/>
            Website: <a href="https://www.mysccg.de/" style="color: #2563eb;">https://www.mysccg.de/</a>
          </p>
        </div>
      </div>
    `}}function h(a){let b=a.tempPassword?`
      <div style="background: #fffbeb; border: 1px solid #f59e0b; border-radius: 8px; padding: 20px; margin: 20px 0;">
        <h3 style="margin: 0 0 12px; font-size: 14px; color: #b45309;">🔐 Your Login Credentials</h3>
        <table style="width: 100%; border-collapse: collapse;">
          <tr><td style="padding: 6px 0; color: #64748b; width: 140px;">Email</td><td style="padding: 6px 0; font-weight: bold;">${a.email}</td></tr>
          <tr><td style="padding: 6px 0; color: #64748b;">Temporary Password</td><td style="padding: 6px 0; font-family: monospace; background: #f1f5f9; padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 15px; letter-spacing: 1px;">${a.tempPassword}</td></tr>
        </table>
        <p style="color: #dc2626; font-size: 13px; margin: 12px 0 0;">⚠️ Please change your password after your first login for security.</p>
      </div>`:`
      <div style="background: #f0fdf4; border: 1px solid #22c55e; border-radius: 8px; padding: 16px; margin: 20px 0;">
        <h3 style="margin: 0 0 12px; font-size: 14px; color: #166534;">🔐 Your Login Details</h3>
        <table style="width: 100%; border-collapse: collapse;">
          <tr><td style="padding: 6px 0; color: #64748b; width: 140px;">Username (Email)</td><td style="padding: 6px 0; font-weight: bold;">${a.email}</td></tr>
        </table>
        <p style="margin: 12px 0 0; color: #166534; font-size: 13px;">✓ You already have an account. Please log in with your existing password. If you have forgotten it, use the “Forgot password” link on the login page.</p>
      </div>`,c=a.totalServiceFee?`<tr><td style="padding: 8px 0; color: #64748b;">Total Service Fee</td><td style="padding: 8px 0; font-weight: bold;">€${a.totalServiceFee.toFixed(2)}</td></tr>`:"";return{subject:"Welcome to SCCG Career Lab Germany — Your Portal Login Details",htmlBody:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #0a1628, #1a2a4a); padding: 32px; border-radius: 12px 12px 0 0;">
          <h1 style="color: #ffffff; margin: 0; font-size: 24px;">Welcome to SCCG Career Lab Germany</h1>
          <p style="color: #94a3b8; margin: 8px 0 0;">Your Portal Account is Ready</p>
        </div>
        <div style="background: #ffffff; padding: 32px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
          <p>Dear <strong>${a.candidateName}</strong>,</p>
          <p>You have been registered by <strong>${a.partnerName}</strong> for the <strong>${a.workflowCategory}</strong> program.</p>
          
          <table style="width: 100%; margin: 16px 0; border-collapse: collapse;">
            <tr><td style="padding: 8px 0; color: #64748b;">Registration ID</td><td style="padding: 8px 0; font-weight: bold;">${a.sccgId}</td></tr>
            <tr><td style="padding: 8px 0; color: #64748b;">Program</td><td style="padding: 8px 0;">${a.workflowCategory}</td></tr>
            ${c}
          </table>

          ${b}

          <div style="text-align: center; margin: 24px 0;">
            <a href="${a.loginUrl}" style="display: inline-block; background: linear-gradient(135deg, #2563eb, #1d4ed8); color: #ffffff; padding: 14px 32px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 16px;">Log In to Your Portal</a>
            <p style="font-size: 13px; color: #64748b; margin-top: 10px;">Portal Link: <a href="${a.loginUrl}" style="color: #2563eb; font-weight: 500;">${a.loginUrl}</a></p>
          </div>

          <p>After logging in, you can:</p>
          <ul style="color: #334155; line-height: 1.8;">
            <li>✓ View your service offers and details</li>
            <li>✓ Track your application timeline</li>
            <li>✓ View payment history</li>
            <li>✓ Send messages to your partner</li>
            <li>✓ Upload required documents</li>
          </ul>
          
          <p style="color: #64748b; font-size: 13px; margin-top: 24px;">
            Best regards,<br/>
            <strong>SCCG Career Lab Germany</strong><br/>
            Website: <a href="https://www.mysccg.de/" style="color: #2563eb;">www.mysccg.de</a>
          </p>
        </div>
      </div>
    `}}function i(a){return{subject:`Certificate of Cooperation — ${a.partnerName} & ${a.subPartnerName}`,htmlBody:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #0a1628, #1a2a4a); padding: 32px; border-radius: 12px 12px 0 0;">
          <h1 style="color: #ffffff; margin: 0; font-size: 24px;">Certificate of Cooperation</h1>
          <p style="color: #94a3b8; margin: 8px 0 0;">SCCG Career Lab Germany</p>
        </div>
        <div style="background: #ffffff; padding: 32px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
          <p>Dear <strong>${a.subPartnerName}</strong> Team,</p>
          <p>We are pleased to share the official <strong>Certificate of Cooperation</strong> confirming the partnership between <strong>${a.partnerName}</strong> (Regional Partner of SCCG Career Lab Germany) and <strong>${a.subPartnerName}</strong>.</p>
          <p>The certificate is attached to this email as a PDF document.</p>
          <div style="background: #f0fdf4; border: 1px solid #22c55e; border-radius: 8px; padding: 16px; margin: 20px 0;">
            <table style="width: 100%; border-collapse: collapse;">
              <tr><td style="padding: 6px 0; color: #64748b; width: 150px;">Certificate Code</td><td style="padding: 6px 0; font-family: monospace; font-weight: bold;">${a.certCode}</td></tr>
            </table>
            <p style="margin: 12px 0 0; font-size: 13px;">Verify online: <a href="${a.verifyUrl}" style="color: #2563eb;">${a.verifyUrl}</a></p>
          </div>
          <p>This cooperation reflects our joint commitment to supporting candidate identification, preparation, and participation in international career development programs. This partnership is non-commercial in nature.</p>
          <p style="color: #64748b; font-size: 13px; margin-top: 24px;">
            Best regards,<br/>
            <strong>${a.partnerName}</strong><br/>
            SCCG Career Lab Germany<br/>
            Website: <a href="https://www.mysccg.de/" style="color: #2563eb;">www.mysccg.de</a>
          </p>
        </div>
      </div>
    `}}function j(a){let b=a.services.map(a=>`<tr><td style="padding: 8px 0; color: #334155;">${a.serviceName}${a.quantity>1?` \xd7 ${a.quantity}`:""}</td><td style="padding: 8px 0; text-align: right; font-weight: bold;">€${a.totalPrice.toFixed(2)}</td></tr>`).join("");return{subject:`New Service Added to Your SCCG Registration — ${a.sccgId}`,htmlBody:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #0a1628, #1a2a4a); padding: 32px; border-radius: 12px 12px 0 0;">
          <h1 style="color: #ffffff; margin: 0; font-size: 24px;">New Service Added</h1>
          <p style="color: #94a3b8; margin: 8px 0 0;">SCCG Career Lab Germany</p>
        </div>
        <div style="background: #ffffff; padding: 32px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
          <p>Dear <strong>${a.candidateName}</strong>,</p>
          <p><strong>${a.partnerName}</strong> has added the following service(s) to your registration (<strong>${a.sccgId}</strong>):</p>
          <table style="width: 100%; margin: 16px 0; border-collapse: collapse;">
            ${b}
            <tr><td style="padding: 10px 0 0; border-top: 1px solid #e2e8f0; color: #64748b;">Added Amount</td><td style="padding: 10px 0 0; border-top: 1px solid #e2e8f0; text-align: right; font-weight: bold;">€${a.addedAmount.toFixed(2)}</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">New Total Service Fee</td><td style="padding: 6px 0; text-align: right; font-weight: bold;">€${a.newTotal.toFixed(2)}</td></tr>
          </table>
          <div style="text-align: center; margin: 24px 0;">
            <a href="${a.loginUrl}" style="display: inline-block; background: linear-gradient(135deg, #2563eb, #1d4ed8); color: #ffffff; padding: 14px 32px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 16px;">View in Your Portal</a>
          </div>
          <p>Log in to your portal to review the updated details, payment information, and your application timeline.</p>
          <p style="color: #64748b; font-size: 13px; margin-top: 24px;">
            Best regards,<br/>
            <strong>SCCG Career Lab Germany</strong><br/>
            Website: <a href="https://www.mysccg.de/" style="color: #2563eb;">www.mysccg.de</a>
          </p>
        </div>
      </div>
    `}}function k(a){let b=a.partnerLogoUrl?`<img src="${a.partnerLogoUrl}" alt="${a.partnerName} logo" style="max-height:60px;max-width:180px;object-fit:contain;margin-bottom:12px;display:block;" />`:"",c=a.services.map(a=>`
      <tr>
        <td style="padding:14px 12px;border-bottom:1px solid #f1f5f9;vertical-align:top;">
          <div style="font-weight:600;color:#0f172a;font-size:14px;">${a.name}</div>
          ${a.category?`<div style="font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:.5px;margin-top:2px;">${a.category}</div>`:""}
          ${a.description?`<div style="font-size:13px;color:#475569;margin-top:6px;line-height:1.5;">${a.description}</div>`:""}
          ${a.includes&&a.includes.length>0?`<ul style="margin:8px 0 0 0;padding:0;list-style:none;">${a.includes.map(a=>`<li style="font-size:12px;color:#2563eb;margin-top:3px;">✓ ${a}</li>`).join("")}</ul>`:a.sessions?`<div style="font-size:12px;color:#2563eb;margin-top:4px;">✓ Includes ${a.sessions} expert session${1!==a.sessions?"s":""}</div>`:""}
        </td>
        <td style="padding:14px 12px;border-bottom:1px solid #f1f5f9;text-align:center;color:#475569;vertical-align:top;font-size:14px;">${a.quantity}</td>
      </tr>`).join(""),d=a.loginPassword?`
    <div style="background:#fffbeb;border:1px solid #f59e0b;border-radius:12px;padding:24px;margin:28px 0;">
      <div style="font-size:15px;font-weight:700;color:#92400e;margin-bottom:14px;">🔐 Your Portal Login Credentials</div>
      <table style="width:100%;border-collapse:collapse;">
        <tr><td style="padding:6px 0;color:#64748b;width:160px;font-size:13px;">Email</td><td style="padding:6px 0;font-weight:600;font-size:13px;">${a.candidateEmail}</td></tr>
        <tr><td style="padding:6px 0;color:#64748b;font-size:13px;">Password</td><td style="padding:6px 0;"><span style="font-family:monospace;background:#fff;border:1px solid #fbbf24;padding:5px 12px;border-radius:6px;font-weight:700;font-size:15px;letter-spacing:1px;">${a.loginPassword}</span></td></tr>
      </table>
      <p style="color:#dc2626;font-size:12px;margin:12px 0 0;">⚠️ Please change your password after your first login.</p>
    </div>`:`
    <div style="background:#f0fdf4;border:1px solid #22c55e;border-radius:12px;padding:16px;margin:28px 0;">
      <p style="margin:0;color:#166534;font-size:14px;">✓ Log in with your existing SCCG Portal credentials to view and accept this offer.</p>
    </div>`,e=a.serviceCategory||"Germany Career Services",f=a.acceptUrl&&a.rejectUrl?`
    <div style="text-align:center;margin:28px 0;">
      <a href="${a.acceptUrl}" style="display:inline-block;background:linear-gradient(135deg,#059669,#047857);color:#fff;padding:14px 36px;border-radius:10px;text-decoration:none;font-weight:700;font-size:15px;margin:0 8px 12px;">
        ✓ Accept Offer
      </a>
      <a href="${a.rejectUrl}" style="display:inline-block;background:#f1f5f9;color:#64748b;padding:14px 36px;border-radius:10px;text-decoration:none;font-weight:700;font-size:15px;margin:0 8px 12px;border:1px solid #e2e8f0;">
        ✗ Decline
      </a>
    </div>`:`
    <div style="text-align:center;margin:28px 0;">
      <a href="${a.loginUrl}" style="display:inline-block;background:linear-gradient(135deg,#0891b2,#0e7490);color:#fff;padding:15px 40px;border-radius:10px;text-decoration:none;font-weight:700;font-size:15px;letter-spacing:.3px;">
        View &amp; Accept Offer →
      </a>
    </div>`;return{subject:`New Service Offer from SCCG Germany — ${e} (Ref: ${a.offerNumber})`,htmlBody:`
<div style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto;background:#f8fafc;padding:20px;">

  <!-- Header card -->
  <div style="background:linear-gradient(135deg,#0a1628,#1a2a4a);border-radius:14px 14px 0 0;padding:28px 32px;">
    ${b}
    <h1 style="color:#fff;margin:0;font-size:22px;font-weight:700;">New Service Offer — SCCG Career Lab Germany</h1>
    <p style="color:#94a3b8;margin:6px 0 0;font-size:13px;">Ref: <strong style="color:#e2e8f0;">${a.offerNumber}</strong> &nbsp;\xb7&nbsp; Valid until ${new Date(a.validUntil).toLocaleDateString("en-GB")}</p>
  </div>

  <!-- Body -->
  <div style="background:#fff;padding:32px;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 14px 14px;">
    <p style="font-size:15px;color:#0f172a;">Dear <strong>${a.candidateName}</strong>,</p>
    <p style="color:#475569;font-size:14px;line-height:1.6;">
      You have received a new offer from <strong>SCCG Career Lab Germany</strong> for 
      <strong>${e}</strong> through our partner <strong>${a.partnerName}</strong>.
    </p>
    <p style="color:#475569;font-size:14px;line-height:1.6;">
      Please review the services included below and click <strong>Accept Offer</strong> to confirm — or <strong>Decline</strong> if you'd like to discuss further.
    </p>

    <!-- Services table (no price columns) -->
    <table style="width:100%;border-collapse:collapse;margin:24px 0;border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;">
      <thead>
        <tr style="background:#f1f5f9;">
          <th style="padding:12px;text-align:left;font-size:12px;color:#64748b;text-transform:uppercase;letter-spacing:.5px;">Service / Package</th>
          <th style="padding:12px;text-align:center;font-size:12px;color:#64748b;text-transform:uppercase;letter-spacing:.5px;width:60px;">Qty</th>
        </tr>
      </thead>
      <tbody>${c}</tbody>
    </table>

    ${a.notes?`<div style="background:#f8fafc;border-left:3px solid #cbd5e1;padding:12px 16px;border-radius:6px;margin:16px 0;"><p style="margin:0;font-size:13px;color:#475569;"><strong>Notes:</strong> ${a.notes}</p></div>`:""}

    <!-- Credentials -->
    ${d}

    <!-- Accept/Reject CTA -->
    ${f}

    <p style="font-size:13px;color:#64748b;line-height:1.6;">
      After accepting you can:<br/>
      ✓ Track your application and service timeline<br/>
      ✓ Upload required documents<br/>
      ✓ Communicate with your consultant<br/>
      ✓ View payment schedule
    </p>

    <hr style="border:none;border-top:1px solid #e2e8f0;margin:28px 0;"/>
    <p style="font-size:12px;color:#94a3b8;margin:0;">
      This offer was sent via <strong>SCCG Partner Portal</strong>. 
      Questions? Contact us at <a href="mailto:info@mysccg.de" style="color:#2563eb;">info@mysccg.de</a> 
      or visit <a href="https://www.mysccg.de/" style="color:#2563eb;">www.mysccg.de</a>.
    </p>
  </div>
</div>`}}},49110:(a,b,c)=>{function d(a,b,c,d){return`€${a.toLocaleString("en",{minimumFractionDigits:0})}`}function e(a,b,c){return`<strong>€${a.toLocaleString("en",{minimumFractionDigits:2})}</strong>`}function f(a,b,c=2){return"number"==typeof b?`€${b.toFixed(c)}`:`€${a.toFixed(c)}`}function g(a,b,c=2){return`€${a.toFixed(c)}`}c.r(b),c.d(b,{dual:()=>d,dualHtml:()=>e,formatBdtEur:()=>f,formatEurWithRate:()=>g})},56994:(a,b,c)=>{c.d(b,{escapeOData:()=>q,getGraphClient:()=>h,getSiteListUrlAsync:()=>p,graphDelete:()=>m,graphGet:()=>i,graphGetSafe:()=>j,graphPatch:()=>l,graphPost:()=>k,listDriveChildren:()=>r,resolveSiteId:()=>o});let d=null;function e(){return"true"===process.env.SP_GRAPH_DEBUG}function f(...a){e()&&console.log("[Graph]",...a)}function g(a){let b={message:a?.message,code:a?.code,statusCode:a?.statusCode,requestId:a?.requestId};return a?.body&&(b.body=a.body),b}async function h(){if(d)return d;let[{ConfidentialClientApplication:a}]=await Promise.all([c.e(3421).then(c.bind(c,93421))]),{Client:b}=await c.e(370).then(c.bind(c,40370));if(!process.env.AZURE_AD_CLIENT_ID||!process.env.AZURE_AD_TENANT_ID||!process.env.AZURE_AD_CLIENT_SECRET)throw Error("MICROSOFT_GRAPH_CONFIG_MISSING");let e=new a({auth:{clientId:process.env.AZURE_AD_CLIENT_ID,authority:`https://login.microsoftonline.com/${process.env.AZURE_AD_TENANT_ID}`,clientSecret:process.env.AZURE_AD_CLIENT_SECRET}});return d=b.init({authProvider:async a=>{try{let b=await e.acquireTokenByClientCredential({scopes:["https://graph.microsoft.com/.default"]});a(null,b?.accessToken||"")}catch(b){a(b,"")}}})}async function i(a){let b=await h();e()&&f("GET",a);try{return await b.api(a).header("Prefer","HonorNonIndexedQueriesWarningMayFailRandomly").get()}catch(b){if(e()&&f("GET_ERROR",a,g(b)),404===b.statusCode||"itemNotFound"===b.code||403===b.statusCode||"accessDenied"===b.code||/access denied/i.test(b.message||""))return{value:[],fields:{}};throw b}}async function j(a){try{let b=await h();return e()&&f("GET_SAFE",a),await b.api(a).header("Prefer","HonorNonIndexedQueriesWarningMayFailRandomly").get()}catch(b){if(404===b.statusCode||"itemNotFound"===b.code||403===b.statusCode||"accessDenied"===b.code||/access denied/i.test(b.message||""))return null;throw e()&&f("GET_SAFE_ERROR",a,g(b)),b}}async function k(a,b){let c=await h();e()&&f("POST",a,b);try{return await c.api(a).post(b)}catch(b){throw e()&&f("POST_ERROR",a,g(b)),b}}async function l(a,b){let c=await h();e()&&f("PATCH",a,b);try{return await c.api(a).patch(b)}catch(b){throw e()&&f("PATCH_ERROR",a,g(b)),b}}async function m(a){let b=await h();e()&&f("DELETE",a);try{await b.api(a).delete()}catch(b){throw e()&&f("DELETE_ERROR",a,g(b)),b}}let n=process.env.SHAREPOINT_SITE_ID??null;async function o(){if(n)return n;let a=process.env.SHAREPOINT_SITE_URL;if(!a)throw Error("Neither SHAREPOINT_SITE_ID nor SHAREPOINT_SITE_URL is set. Set one to allow Graph site resolution.");let b=new URL(a),c=b.hostname,d=b.pathname||"/",e=d.indexOf("/sites/"),f=d.indexOf("/teams/"),g="/",h=(g=-1!==e?d.slice(e):-1!==f?d.slice(f):d).search(/\/SitePages|\/Lists|\/_layouts|\/Pages/);-1!==h&&(g=g.slice(0,h)),(g=g.replace(/\/+$/,"")).startsWith("/")||(g="/"+g);let j=`/sites/${c}:${g}`,k=await i(j);if(!k||!k.id)throw Error(`Unable to resolve SharePoint site for ${a}`);n=k.id;try{process.env.SHAREPOINT_SITE_ID=n}catch(a){}return n}async function p(a){let b=await o();return`/sites/${b}/lists/${a}/items`}function q(a){return String(a).replace(/[\x00-\x1f\x7f]/g,"").replace(/'/g,"''")}async function r(a){try{let b=await h(),c=await o(),d=String(a).replace(/\\/g,"/").split("/").map(a=>a.replace(/[<>:"|?*\x00-\x1f]/g,"").replace(/\.{2,}/g,"").trim()).filter(Boolean).join("/"),e=d?`/sites/${c}/drive/root:/${d}:/children`:`/sites/${c}/drive/root/children`,f=await b.api(e).get();return f?.value||[]}catch(a){if(404===a.statusCode||"itemNotFound"===a.code||403===a.statusCode||"accessDenied"===a.code||/access denied/i.test(a.message||""))return[];throw a}}}};