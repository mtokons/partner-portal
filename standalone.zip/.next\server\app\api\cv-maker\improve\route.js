var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cv-maker/improve/route.js")
R.c("server/chunks/[root-of-the-server]__05y4kbd._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_cv-maker_improve_route_actions_08nlh1x.js")
R.m(144008)
module.exports=R.m(144008).exports
