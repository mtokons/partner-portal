var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cv-maker/extract/route.js")
R.c("server/chunks/[root-of-the-server]__0es9s_3._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_cv-maker_extract_route_actions_0x05r3u.js")
R.m(528501)
module.exports=R.m(528501).exports
