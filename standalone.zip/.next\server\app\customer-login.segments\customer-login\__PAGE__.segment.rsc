1:"$Sreact.fragment"
3:I[897367,["/_next/static/chunks/0ps5ylv66v0zo.js","/_next/static/chunks/0i.l9589uvx0j.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"jPda1FAgEFkUgAJ6jbUW8"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/login?portal=customer;307;"}
