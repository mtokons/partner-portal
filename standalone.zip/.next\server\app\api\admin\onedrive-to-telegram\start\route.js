var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/onedrive-to-telegram/start/route.js")
R.c("server/chunks/[root-of-the-server]__0zm~q.-._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/[root-of-the-server]__0waxf4z._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/0zjb_server_app_api_admin_onedrive-to-telegram_start_route_actions_0b92p9k.js")
R.m(114046)
module.exports=R.m(114046).exports
