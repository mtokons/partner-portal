var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/livez/route.js")
R.c("server/chunks/[root-of-the-server]__11efa_i._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/_next-internal_server_app_api_livez_route_actions_0k7yh5y.js")
R.m(768873)
module.exports=R.m(768873).exports
