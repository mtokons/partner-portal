var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cv-maker/render/route.js")
R.c("server/chunks/[root-of-the-server]__0p844y3._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_cv-maker_render_route_actions_0k5.xnh.js")
R.m(387657)
module.exports=R.m(387657).exports
