1:"$Sreact.fragment"
2:I[855465,["/_next/static/chunks/0ps5ylv66v0zo.js","/_next/static/chunks/0i.l9589uvx0j.js","/_next/static/chunks/130jxldfnpn-0.js","/_next/static/chunks/0~-gme8k.h~-1.js"],"default"]
3:I[897367,["/_next/static/chunks/0ps5ylv66v0zo.js","/_next/static/chunks/0i.l9589uvx0j.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/130jxldfnpn-0.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/0~-gme8k.h~-1.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"jPda1FAgEFkUgAJ6jbUW8"}
5:null
