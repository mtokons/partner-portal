var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/model-test/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__0vkhbow._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_model-test_[___path]_route_actions_0qr5xm_.js")
R.m(18292)
module.exports=R.m(18292).exports
