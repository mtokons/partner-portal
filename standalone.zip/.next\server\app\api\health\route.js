var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[root-of-the-server]__0_5be2k._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/_next-internal_server_app_api_health_route_actions_0-jjhgq.js")
R.m(243007)
module.exports=R.m(243007).exports
