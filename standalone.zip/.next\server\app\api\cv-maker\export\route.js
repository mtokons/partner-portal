var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cv-maker/export/route.js")
R.c("server/chunks/[root-of-the-server]__0an6dkw._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_cv-maker_export_route_actions_13nr55x.js")
R.m(869949)
module.exports=R.m(869949).exports
