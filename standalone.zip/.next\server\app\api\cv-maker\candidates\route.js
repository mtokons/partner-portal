var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cv-maker/candidates/route.js")
R.c("server/chunks/[root-of-the-server]__12q-msk._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/src_lib_sharepoint_ts_0~k-geq._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_cv-maker_candidates_route_actions_0lyevj-.js")
R.m(233841)
module.exports=R.m(233841).exports
