var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/clients/route.js")
R.c("server/chunks/[root-of-the-server]__058a4ls._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/src_lib_sharepoint_ts_0~k-geq._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_clients_route_actions_0zqanza.js")
R.m(356913)
module.exports=R.m(356913).exports
