var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cv-maker/parse/route.js")
R.c("server/chunks/[root-of-the-server]__095_qe5._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_cv-maker_parse_route_actions_0cxblyl.js")
R.m(45614)
module.exports=R.m(45614).exports
