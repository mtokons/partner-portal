var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/onedrive-to-telegram/folders/route.js")
R.c("server/chunks/[root-of-the-server]__0v7qnuw._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/0zjb_server_app_api_admin_onedrive-to-telegram_folders_route_actions_03juq0i.js")
R.m(389692)
module.exports=R.m(389692).exports
