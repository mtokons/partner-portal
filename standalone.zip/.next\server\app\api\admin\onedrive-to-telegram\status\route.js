var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/onedrive-to-telegram/status/route.js")
R.c("server/chunks/[root-of-the-server]__0d2rqt.._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/[root-of-the-server]__0waxf4z._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/0zjb_server_app_api_admin_onedrive-to-telegram_status_route_actions_0m79~2m.js")
R.m(634400)
module.exports=R.m(634400).exports
