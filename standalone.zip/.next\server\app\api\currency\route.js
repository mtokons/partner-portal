var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/currency/route.js")
R.c("server/chunks/[root-of-the-server]__040615j._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_currency_route_actions_0ci-4~9.js")
R.m(391408)
module.exports=R.m(391408).exports
