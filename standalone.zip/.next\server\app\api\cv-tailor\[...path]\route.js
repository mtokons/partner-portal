var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cv-tailor/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__0ljcit0._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_cv-tailor_[___path]_route_actions_0bk_cc7.js")
R.m(644285)
module.exports=R.m(644285).exports
