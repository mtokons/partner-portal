var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/onedrive-to-telegram/quota/route.js")
R.c("server/chunks/[root-of-the-server]__0wkxfd~._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/[root-of-the-server]__0945oel._.js")
R.c("server/chunks/0zjb_server_app_api_admin_onedrive-to-telegram_quota_route_actions_07p741y.js")
R.m(376574)
module.exports=R.m(376574).exports
